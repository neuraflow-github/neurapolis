from retriever.services.db_session_builder import db_session_builder

if __name__ == "__main__":
    # Find path

    # Schema as text
    with db_session_builder.build() as db_session:
        result = db_session.run("CALL apoc.meta.schema()")
        schema = result.single()["value"]
        print(schema)

    # Prompt

    # Structured output with possible connections nothing more

    # then call and print
